const weatherService = require("../services/weatherService");

async function getWeather(req, res, next) {
  try {
    const city = typeof req.query.city === "string"
      ? req.query.city.trim()
      : "";

    if (!city) {
      return res.status(400).json({
        success: false,
        message: "Please provide a city name."
      });
    }

    if (city.length > 100) {
      return res.status(400).json({
        success: false,
        message: "City name must be 100 characters or fewer."
      });
    }

    const weather = await weatherService.getWeather(city);

    return res.status(200).json({
      success: true,
      data: weather
    });
  } catch (error) {
    next(error);
  }
}

module.exports = { getWeather };