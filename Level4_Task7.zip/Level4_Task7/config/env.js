require("dotenv").config();

const port = Number(process.env.PORT || 5000);
const weatherApiKey = process.env.WEATHER_API_KEY;

if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("PORT must be a valid port number.");
}

if (!weatherApiKey) {
  throw new Error("WEATHER_API_KEY is missing from the .env file.");
}

module.exports = {
  port,
  weatherApiKey
};