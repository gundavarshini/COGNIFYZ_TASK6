function errorHandler(err, req, res, next) {
  console.error(err.message);

  if (res.headersSent) {
    return next(err);
  }

  const status = Number.isInteger(err.status)
    ? err.status
    : 500;

  return res.status(status).json({
    success: false,
    message: status >= 500 && status !== 502 && status !== 503 && status !== 504
      ? "An unexpected server error occurred."
      : err.message
  });
}

module.exports = errorHandler;