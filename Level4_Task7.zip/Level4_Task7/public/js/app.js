const weatherForm = document.getElementById("weatherForm");
const cityInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const message = document.getElementById("message");
const weatherPanel = document.getElementById("weatherPanel");

const fields = {
  location: document.getElementById("location"),
  description: document.getElementById("weatherDescription"),
  temperature: document.getElementById("temperature"),
  feelsLike: document.getElementById("feelsLike"),
  humidity: document.getElementById("humidity"),
  windSpeed: document.getElementById("windSpeed"),
  pressure: document.getElementById("pressure"),
  visibility: document.getElementById("visibility"),
  icon: document.getElementById("weatherIcon")
};

function showMessage(text) {
  message.textContent = text;
}

function displayWeather(weather) {
  fields.location.textContent =
    `${weather.city}${weather.country ? ", " + weather.country : ""}`;

  fields.description.textContent = weather.description;
  fields.temperature.textContent = Math.round(weather.temperature);
  fields.feelsLike.textContent = Math.round(weather.feelsLike);
  fields.humidity.textContent = weather.humidity;
  fields.windSpeed.textContent = weather.windSpeed;
  fields.pressure.textContent = weather.pressure;

  fields.visibility.textContent = weather.visibility === null
    ? "N/A"
    : (weather.visibility / 1000).toFixed(1);

  if (weather.icon) {
    fields.icon.src =
      `https://openweathermap.org/img/wn/${encodeURIComponent(weather.icon)}@2x.png`;
    fields.icon.alt = weather.description;
    fields.icon.hidden = false;
  } else {
    fields.icon.hidden = true;
    fields.icon.removeAttribute("src");
  }

  weatherPanel.hidden = false;
}

weatherForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const city = cityInput.value.trim();

  if (!city) {
    showMessage("Please enter a city name.");
    return;
  }

  searchBtn.disabled = true;
  searchBtn.textContent = "Loading...";
  showMessage("");

  try {
    const response = await fetch(
      `/api/weather?city=${encodeURIComponent(city)}`
    );

    const result = await response.json();

    if (!response.ok || !result.success) {
      throw new Error(result.message || "Unable to retrieve weather.");
    }

    displayWeather(result.data);
    showMessage("");
  } catch (error) {
    showMessage(
      error.message || "Unable to connect to the server. Please try again."
    );
  } finally {
    searchBtn.disabled = false;
    searchBtn.innerHTML = "Search <span>→</span>";
  }
});