const express = require("express");
const apiController = require("../controllers/apiController");

const router = express.Router();

router.get("/weather", apiController.getWeather);

module.exports = router;