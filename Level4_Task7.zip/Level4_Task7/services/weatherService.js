
const { weatherApiKey } = require("../config/env");

async function getWeather(city) {
  const url = new URL(
    "https://api.openweathermap.org/data/2.5/weather"
  );

  url.searchParams.set("q", city);
  url.searchParams.set("appid", weatherApiKey);
  url.searchParams.set("units", "metric");

  let response;

  try {
    response = await fetch(url, {
      signal: AbortSignal.timeout(10000)
    });
  } catch (error) {
    const err = new Error(
      "Unable to connect to the weather service. Please try again."
    );
    err.status = 502;
    throw err;
  }

  const data = await response.json();

  if (!response.ok) {
    const err = new Error(
      data.message === "city not found"
        ? "City not found. Please check the city name."
        : response.status === 401
          ? "Invalid API key. Check your OpenWeather API key."
          : "Weather service request failed."
    );

    err.status = response.status === 404 ? 404 : 502;
    throw err;
  }

  return {
    city: data.name,
    country: data.sys?.country || "",
    temperature: data.main.temp,
    feelsLike: data.main.feels_like,
    humidity: data.main.humidity,
    pressure: data.main.pressure,
    description: data.weather?.[0]?.description || "Unavailable",
    icon: data.weather?.[0]?.icon || "",
    windSpeed: data.wind?.speed ?? 0,
    visibility: data.visibility ?? null
  };
}

module.exports = { getWeather };
